let rectX = 0;
let fr = 30;
let clr;

function setup() {
  background(10);
  frameRate(fr); 
  clr = color(255, 0, 0);
}

function draw() {
  background(10);
  rectX += 1;

  if (rectX >= width) {
    if (fr === 30) {
      clr = color(0, 0, 255);
      fr = 5;
      frameRate(fr); 
    } else {
      clr = color(255, 0, 0);
      fr = 60;
      frameRate(fr); 
    }
    rectX = 0;
  }
  fill(clr);
  rect(rectX, 40, 20, 20);
}