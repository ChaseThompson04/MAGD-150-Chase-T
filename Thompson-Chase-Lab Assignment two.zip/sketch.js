function setup() {
  createCanvas(128,128);
  background(200)
}

function draw() {
  fill('red')
 ellipse(60, 60, 20, 20);
  
  fill('green')
  ellipse(100,80,20,20)
  
  fill('yellow')
  ellipse(10,10,50,50)
  
  fill('blue')
  ellipse(55,20,20,20)
  
  fill('pink')
  ellipse(75,100,20,20)
  
  strokeWeight(5);
point(94, 100);
point(74, 19);
point(30, 40);
point(55, 91);
strokeWeight(1);
  
  beginShape(LINES);
vertex(40, 30);
vertex(60, 20);
vertex(60, 75);
vertex(30, 75);
endShape();
}
