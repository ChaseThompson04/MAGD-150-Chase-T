var x = 120;

var y = 60;

var radius = 12;



function setup() {

	createCanvas(400,400);

	ellipseMode (RADIUS);

}

function draw() {

	background (200);

	var d = dist(mouseX, mouseY, x, y);

	if (d < radius) {

		radius++;

		fill(0);

	} else {

		fill (255);

	}
	
	ellipse(x, y, radius, radius);

}
var x;

var offset = 10;

function setup() {

	createCanvas(240, 120);

	x = width/2;

}

function draw() {

	background(200);

	if (mouseX > x) {

		x += 0.5;
		offset = -10;

	}

	if (mouseX < x) {

		x -= 0.5;
		offset = 10;

	}

	// Draw arrow left or right depending on "offset" value

	line(x, 0, x, height);

	line (mouseX, mouseY, mouseX + offset, mouseY - 10);

	line (mouseX, mouseY, mouseX + offset, mouseY + 10);
	
	line (mouseX, mouseY, mouseX + offset * 3, mouseY);

}
var x = 80;

var y = 50;

var w = 80;

var h = 60;



function setup() {

	createCanvas(400,400);

}

function draw() {

	background (200);

	if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) {
		
		fill(0);
	}

	else {

		fill (255);

	}
	
	rect(x, y, w, h);
}
var x = 100;

var y = 100;

var w = 120;

var h = 70;



function setup() {

	createCanvas(400,400);

	background (200);

	rect(x, y, w, h);

}

function mousePressed() {

	background (200);

	if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) {
		
		fill(0);

	}

	else {

		fill (255);

	}
	
	rect(x, y, w, h);
}
var x = 200;

var y = 120;

var radius = 12;



function setup() {

	createCanvas(400,400);

	ellipseMode (RADIUS);

	ellipse(x, y, radius, radius);
}

function draw() {

	background (200);

	var d = dist(mouseX, mouseY, x, y);

	if (keyIsPressed) {
		
		if (key == 'x') {
				
				if (d < radius) {
					
					radius++;
					
					fill(0);

				} else {
				
				fill (255);
				
				}

		}
	}

	ellipse(x, y, radius, radius);

}

